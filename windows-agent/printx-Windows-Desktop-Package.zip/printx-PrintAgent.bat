<# :
@echo off
setlocal
title printx - Windows Desktop Spooler Agent
color 0b

:: Self-elevating or direct execution script that looks and behaves like an executable installer
echo ======================================================================
echo    printx - Windows Desktop Printing Agent v2.4
echo    Native Windows Spooler Connector for Shop Workstations
echo ======================================================================
echo.

set "APP_DIR=%USERPROFILE%\printx-PrintAgent"
if not exist "%APP_DIR%" mkdir "%APP_DIR%"
cd /d "%APP_DIR%"

echo [*] Initializing Windows Desktop Workstation components...
powershell -NoProfile -ExecutionPolicy Bypass -Command "& ([ScriptBlock]::Create((Get-Content -Path '%~f0' -Raw)))"
goto :eof
#>

$ErrorActionPreference = "SilentlyContinue"
$Host.UI.RawUI.WindowTitle = "printx - Desktop Print Agent"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "    printx - Windows Native Desktop Agent" -ForegroundColor Yellow
Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host ""

$WorkDir = Join-Path $env:USERPROFILE "printx-PrintAgent"
if (!(Test-Path $WorkDir)) {
    New-Item -ItemType Directory -Force -Path $WorkDir | Out-Null
}
Set-Location $WorkDir

# Check if Python is installed
$PythonCmd = Get-Command python -ErrorAction SilentlyContinue

if (!$PythonCmd) {
    Write-Host "[!] Python is not installed or not in PATH." -ForegroundColor Yellow
    Write-Host "[*] Launching standalone Windows PowerShell Background Spooler..." -ForegroundColor Green
    Write-Host "This will connect directly to your shop printers without requiring Python!" -ForegroundColor Cyan
    Write-Host ""
}

# WinForms GUI in PowerShell (Works on 100% of Windows 10 & 11 PCs without installing anything!)
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$Form = New-Object System.Windows.Forms.Form
$Form.Text = "printx - Windows Desktop Spooler Agent"
$Form.Size = New-Object System.Drawing.Size(720, 560)
$Form.StartPosition = "CenterScreen"
$Form.BackColor = [System.Drawing.Color]::FromArgb(248, 250, 252)

# Title
$TitleLabel = New-Object System.Windows.Forms.Label
$TitleLabel.Text = "printx Desktop Agent"
$TitleLabel.Font = New-Object System.Drawing.Font("Segoe UI", 14, [System.Drawing.FontStyle]::Bold)
$TitleLabel.Location = New-Object System.Drawing.Point(20, 15)
$TitleLabel.Size = New-Object System.Drawing.Size(400, 30)
$TitleLabel.ForeColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
$Form.Controls.Add($TitleLabel)

# Status Badge
$StatusBadge = New-Object System.Windows.Forms.Label
$StatusBadge.Text = "Ready to Connect"
$StatusBadge.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$StatusBadge.Location = New-Object System.Drawing.Point(520, 18)
$StatusBadge.Size = New-Object System.Drawing.Size(160, 25)
$StatusBadge.TextAlign = "MiddleCenter"
$StatusBadge.BackColor = [System.Drawing.Color]::FromArgb(226, 232, 240)
$StatusBadge.ForeColor = [System.Drawing.Color]::FromArgb(71, 85, 105)
$Form.Controls.Add($StatusBadge)

# Server Input
$ServerLabel = New-Object System.Windows.Forms.Label
$ServerLabel.Text = "Shop Server URL:"
$ServerLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$ServerLabel.Location = New-Object System.Drawing.Point(20, 60)
$ServerLabel.Size = New-Object System.Drawing.Size(120, 20)
$Form.Controls.Add($ServerLabel)

$ConfigFile = Join-Path $PSScriptRoot "printx-agent-config.json"
$SavedServer = "https://ais-dev-j4wzxf4ek3yadrvyzajprv-973482974092.asia-southeast1.run.app"
$SavedCode = ""
if (Test-Path $ConfigFile) {
    try {
        $cfg = Get-Content $ConfigFile -Raw | ConvertFrom-Json
        if ($cfg.server_url) { $SavedServer = $cfg.server_url }
        if ($cfg.pairing_code) { $SavedCode = $cfg.pairing_code }
    } catch {}
}

$ServerBox = New-Object System.Windows.Forms.TextBox
$ServerBox.Text = $SavedServer
$ServerBox.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$ServerBox.Location = New-Object System.Drawing.Point(140, 58)
$ServerBox.Size = New-Object System.Drawing.Size(540, 24)
$Form.Controls.Add($ServerBox)

# Pairing Code / Utility Key
$KeyLabel = New-Object System.Windows.Forms.Label
$KeyLabel.Text = "6-Digit Pair Code:"
$KeyLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$KeyLabel.Location = New-Object System.Drawing.Point(20, 95)
$KeyLabel.Size = New-Object System.Drawing.Size(120, 20)
$Form.Controls.Add($KeyLabel)

$KeyBox = New-Object System.Windows.Forms.TextBox
$KeyBox.Text = $SavedCode
$KeyBox.Font = New-Object System.Drawing.Font("Segoe UI", 11, [System.Drawing.FontStyle]::Bold)
$KeyBox.Location = New-Object System.Drawing.Point(140, 92)
$KeyBox.Size = New-Object System.Drawing.Size(160, 26)
$Form.Controls.Add($KeyBox)

# Printer Selection
$PrinterLabel = New-Object System.Windows.Forms.Label
$PrinterLabel.Text = "Target Printer:"
$PrinterLabel.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$PrinterLabel.Location = New-Object System.Drawing.Point(320, 95)
$PrinterLabel.Size = New-Object System.Drawing.Size(100, 20)
$Form.Controls.Add($PrinterLabel)

$PrinterBox = New-Object System.Windows.Forms.ComboBox
$PrinterBox.DropDownStyle = "DropDownList"
$PrinterBox.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$PrinterBox.Location = New-Object System.Drawing.Point(420, 92)
$PrinterBox.Size = New-Object System.Drawing.Size(260, 24)

# Detect Windows Printers natively
try {
    $Printers = Get-CimInstance Win32_Printer | Select-Object -ExpandProperty Name
    foreach ($p in $Printers) {
        $PrinterBox.Items.Add($p) | Out-Null
    }
} catch {
    $PrinterBox.Items.Add("Default Windows Printer") | Out-Null
}

if ($PrinterBox.Items.Count -gt 0) {
    $PrinterBox.SelectedIndex = 0
}
$Form.Controls.Add($PrinterBox)

# Connect Button
$ConnectBtn = New-Object System.Windows.Forms.Button
$ConnectBtn.Text = "Connect & Stay Online"
$ConnectBtn.Font = New-Object System.Drawing.Font("Segoe UI", 9.5, [System.Drawing.FontStyle]::Bold)
$ConnectBtn.Location = New-Object System.Drawing.Point(20, 135)
$ConnectBtn.Size = New-Object System.Drawing.Size(180, 36)
$ConnectBtn.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
$ConnectBtn.ForeColor = [System.Drawing.Color]::White
$ConnectBtn.FlatStyle = "Flat"
$Form.Controls.Add($ConnectBtn)

# Dedicated Logout / Disconnect Button
$LogoutBtn = New-Object System.Windows.Forms.Button
$LogoutBtn.Text = "Logout / Unpair"
$LogoutBtn.Font = New-Object System.Drawing.Font("Segoe UI", 9, [System.Drawing.FontStyle]::Bold)
$LogoutBtn.Location = New-Object System.Drawing.Point(210, 135)
$LogoutBtn.Size = New-Object System.Drawing.Size(130, 36)
$LogoutBtn.BackColor = [System.Drawing.Color]::FromArgb(241, 245, 249)
$LogoutBtn.ForeColor = [System.Drawing.Color]::FromArgb(100, 116, 139)
$LogoutBtn.FlatStyle = "Flat"
$Form.Controls.Add($LogoutBtn)

# Dry Run Checkbox
$DryRunBox = New-Object System.Windows.Forms.CheckBox
$DryRunBox.Text = "Test Simulation Mode (Print without paper)"
$DryRunBox.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
$DryRunBox.Location = New-Object System.Drawing.Point(360, 142)
$DryRunBox.Size = New-Object System.Drawing.Size(300, 24)
$DryRunBox.Checked = $false
$Form.Controls.Add($DryRunBox)

# Log Window
$LogBox = New-Object System.Windows.Forms.TextBox
$LogBox.Multiline = $true
$LogBox.ScrollBars = "Vertical"
$LogBox.ReadOnly = $true
$LogBox.Font = New-Object System.Drawing.Font("Consolas", 9)
$LogBox.BackColor = [System.Drawing.Color]::FromArgb(15, 23, 42)
$LogBox.ForeColor = [System.Drawing.Color]::FromArgb(56, 189, 248)
$LogBox.Location = New-Object System.Drawing.Point(20, 190)
$LogBox.Size = New-Object System.Drawing.Size(660, 300)
$Form.Controls.Add($LogBox)

function LogMessage($msg) {
    $time = (Get-Date).ToString("HH:mm:ss")
    $LogBox.AppendText("[$time] $msg`r`n")
}

LogMessage "printx Windows Agent v2.5 initialized."
LogMessage "Detected local printers: $($PrinterBox.Items.Count) available."
LogMessage "Permanent 6-Digit Pairing Code connects 24/7 until you click 'Logout'."

# Timer for Background Job Polling
$Timer = New-Object System.Windows.Forms.Timer
$Timer.Interval = 2000
$Global:AgentToken = ""
$Global:IsConnected = $false
$Global:PairingCode = $SavedCode

function ConnectShopAgent($isSilent = $false) {
    $Server = $ServerBox.Text.Trim().TrimEnd('/')
    if ($Server -notmatch '^https?://') {
        $Server = "https://$Server"
        $ServerBox.Text = $Server
    }
    $Code = $KeyBox.Text.Trim()
    if ($Code.Length -lt 4) {
        if (!$isSilent) {
            [System.Windows.Forms.MessageBox]::Show("Please enter the 6-Digit Pairing Code from your Shop Dashboard.", "Input Required")
        }
        return
    }

    $Global:PairingCode = $Code
    LogMessage "Connecting to $Server with fixed code '$Code'..."

    try {
        $body = @{
            pairingCode = $Code
            deviceName = $env:COMPUTERNAME
        } | ConvertTo-Json

        $resp = Invoke-RestMethod -Uri "$Server/api/agent/pair" -Method Post -Body $body -ContentType "application/json" -TimeoutSec 15

        if ($resp.token) {
            $Global:AgentToken = $resp.token
            $Global:IsConnected = $true

            # Save config permanently so restart/reboot reconnects automatically
            try {
                @{
                    server_url = $Server
                    pairing_code = $Code
                    agent_token = $resp.token
                } | ConvertTo-Json | Set-Content $ConfigFile -Force
            } catch {}

            $ConnectBtn.Text = "Connected (24/7)"
            $ConnectBtn.BackColor = [System.Drawing.Color]::FromArgb(16, 185, 129)
            $StatusBadge.Text = "Online (Connected)"
            $StatusBadge.BackColor = [System.Drawing.Color]::FromArgb(209, 250, 229)
            $StatusBadge.ForeColor = [System.Drawing.Color]::FromArgb(6, 95, 70)
            LogMessage "SUCCESS: Windows Agent paired and connected!"
            LogMessage "Active Shop: $($resp.shopId)"
            LogMessage "Continuous 24/7 spooler monitoring active..."
            $Timer.Start()
        }
    } catch {
        $errDetail = $_.Exception.Message
        LogMessage "Connection attempt note: $errDetail"
        if (!$isSilent) {
            [System.Windows.Forms.MessageBox]::Show("Connection note: $errDetail`n`nPlease verify your server URL and 6-digit code in Shop Dashboard.", "Connection")
        }
    }
}

$ConnectBtn.Add_Click({
    ConnectShopAgent($false)
})

# Explicit Logout handler
$LogoutBtn.Add_Click({
    $Timer.Stop()
    $Global:IsConnected = $false
    $Global:AgentToken = ""
    $Global:PairingCode = ""
    $KeyBox.Text = ""
    if (Test-Path $ConfigFile) {
        try { Remove-Item $ConfigFile -Force } catch {}
    }
    $ConnectBtn.Text = "Connect & Stay Online"
    $ConnectBtn.BackColor = [System.Drawing.Color]::FromArgb(37, 99, 235)
    $StatusBadge.Text = "Logged Out"
    $StatusBadge.BackColor = [System.Drawing.Color]::FromArgb(254, 226, 226)
    $StatusBadge.ForeColor = [System.Drawing.Color]::FromArgb(185, 28, 28)
    LogMessage "Logged out from shop. Device unlinked until new code is entered."
})

# Auto-connect immediately when form is displayed if code is saved!
$Form.Add_Shown({
    if ($SavedCode -and $SavedCode.Length -ge 4) {
        LogMessage "Found saved permanent 6-digit code '$SavedCode'. Auto-connecting now..."
        ConnectShopAgent($true)
    }
})

$Timer.Add_Tick({
    if (!$Global:IsConnected) { return }

    $Server = $ServerBox.Text.Trim().TrimEnd('/')
    $headers = @{
        "Authorization" = "Bearer $Global:AgentToken"
        "x-agent-token" = "$Global:AgentToken"
    }

    try {
        # 1. Send Heartbeat
        $hbBody = @{
            status = "online"
            activePrinter = $PrinterBox.Text
        } | ConvertTo-Json
        Invoke-RestMethod -Uri "$Server/api/agent/heartbeat" -Method Post -Headers $headers -Body $hbBody -ContentType "application/json" -TimeoutSec 5 | Out-Null

        # 2. Poll Jobs
        $jobsResp = Invoke-RestMethod -Uri "$Server/api/agent/jobs" -Method Get -Headers $headers -TimeoutSec 5
        if ($jobsResp.jobs -and $jobsResp.jobs.Count -gt 0) {
            foreach ($job in $jobsResp.jobs) {
                $jobId = $job.jobId
                $orderNum = $job.orderNumber
                $docName = $job.documentName
                $fileIdx = if ($job.fileIndex) { $job.fileIndex } else { 1 }
                $totalF = if ($job.totalFiles) { $job.totalFiles } else { 1 }

                LogMessage "NEW PRINT JOB: #$orderNum - File $fileIdx/$totalF ($docName)"

                # Claim job
                $claimResp = Invoke-RestMethod -Uri "$Server/api/agent/jobs/$jobId/claim" -Method Post -Headers $headers -TimeoutSec 5
                $claimToken = $claimResp.claimToken

                if ($claimToken) {
                    LogMessage "Claimed job $jobId for #$orderNum (File $fileIdx/$totalF). Spooling to '$($PrinterBox.Text)'..."

                    # Download file via dynamic URL or fallback endpoint
                    # Sanitize filename to avoid invalid Windows path characters
                    $cleanName = [System.IO.Path]::GetFileName($docName) -replace '[^a-zA-Z0-9_\-\.]', '_'
                    if (!$cleanName -or $cleanName.Length -lt 3) {
                        $cleanName = "document_$fileIdx"
                    }
                    $ext = [System.IO.Path]::GetExtension($cleanName).ToLower()
                    if (!$ext -or $ext.Length -lt 2) {
                        $docTypeStr = "$($job.documentType)".ToLower()
                        if ($docTypeStr -match 'png') { $ext = '.png' }
                        elseif ($docTypeStr -match 'jpe?g') { $ext = '.jpg' }
                        elseif ($docTypeStr -match 'webp') { $ext = '.webp' }
                        else { $ext = '.pdf' }
                        $cleanName = "$cleanName$ext"
                    }

                    $tmpFile = Join-Path $WorkDir "$orderNum-file$fileIdx-$cleanName"
                    $dlUri = "$Server/api/agent/jobs/$jobId/document?token=$claimToken"
                    if ($job.downloadUrl) {
                        $dlUri = "$Server$($job.downloadUrl)"
                    }

                    LogMessage "[DOWNLOADING] Fetching file $fileIdx/$totalF ($cleanName)..."
                    try {
                        Invoke-RestMethod -Uri $dlUri -Headers $headers -OutFile $tmpFile -TimeoutSec 20
                    } catch {
                        try {
                            Invoke-WebRequest -Uri $dlUri -Headers $headers -OutFile $tmpFile -TimeoutSec 20
                        } catch {}
                    }

                    if (!(Test-Path $tmpFile) -or ((Get-Item $tmpFile).Length -lt 250)) {
                        $fSize = if (Test-Path $tmpFile) { (Get-Item $tmpFile).Length } else { 0 }
                        LogMessage "[ERROR] File $fileIdx/$totalF download incomplete ($fSize bytes). Skipping print to prevent blank paper."
                        $report = @{ claimToken = $claimToken; status = "failed"; errorMessage = "Downloaded file was empty or missing on server ($fSize bytes)" } | ConvertTo-Json
                        Invoke-RestMethod -Uri "$Server/api/agent/jobs/$jobId/report" -Method Post -Headers $headers -Body $report -ContentType "application/json" -TimeoutSec 5 | Out-Null
                        continue
                    }

                    # Verify downloaded file is not a server JSON error response
                    $firstBytes = Get-Content -Path $tmpFile -TotalCount 2 -Raw
                    if ($firstBytes -and $firstBytes.Trim().StartsWith('{"error"')) {
                        LogMessage "[ERROR] Server returned error for file $fileIdx/$totalF. Skipping to prevent blank paper."
                        $report = @{ claimToken = $claimToken; status = "failed"; errorMessage = "Server error response" } | ConvertTo-Json
                        Invoke-RestMethod -Uri "$Server/api/agent/jobs/$jobId/report" -Method Post -Headers $headers -Body $report -ContentType "application/json" -TimeoutSec 5 | Out-Null
                        continue
                    }

                    if ($DryRunBox.Checked) {
                        LogMessage "[TEST MODE] Simulated print of file $fileIdx/$totalF ($cleanName) completed."
                    } else {
                        $targetPrinter = if ($PrinterBox.SelectedItem) {
                            $PrinterBox.SelectedItem.ToString()
                        } elseif ($PrinterBox.Text -and $PrinterBox.Text -ne "Default Windows Printer") {
                            $PrinterBox.Text
                        } elseif ($job.targetPrinter -and $job.targetPrinter -ne "Default Windows Printer") {
                            $job.targetPrinter
                        } else {
                            "Default Windows Printer"
                        }

                        # Dynamically set selected printer as default so printto / print always routes directly without failing
                        if ($targetPrinter -and $targetPrinter -ne "Default Windows Printer") {
                            try {
                                (New-Object -ComObject WScript.Network).SetDefaultPrinter($targetPrinter)
                            } catch {}
                        }
                        $ext = [System.IO.Path]::GetExtension($tmpFile).ToLower()
                        if ($ext -match '\.(jpg|jpeg|png|webp|bmp)$') {
                            # Reliable headless GDI+ .NET image printing (memory stream + safe bounds + Pixel units)
                            try {
                                Add-Type -AssemblyName System.Drawing
                                $pdoc = New-Object System.Drawing.Printing.PrintDocument
                                $pdoc.OriginAtMargins = $false
                                $pdoc.DefaultPageSettings.Margins = New-Object System.Drawing.Printing.Margins(15, 15, 15, 15)
                                if ($targetPrinter -and $targetPrinter -ne "Default Windows Printer") {
                                    $pdoc.PrinterSettings.PrinterName = $targetPrinter
                                }

                                $rawBytes = [System.IO.File]::ReadAllBytes($tmpFile)
                                $ms = New-Object System.IO.MemoryStream(,$rawBytes)
                                $script:currentPrintImg = [System.Drawing.Bitmap]::FromStream($ms)

                                $pdoc.add_PrintPage({
                                    param($sender, $ev)
                                    try {
                                        if ($script:currentPrintImg) {
                                            $paperW = [Math]::Max(100, $ev.PageBounds.Width)
                                            $paperH = [Math]::Max(100, $ev.PageBounds.Height)
                                            $margin = 25
                                            $availW = [Math]::Max(50, $paperW - ($margin * 2))
                                            $availH = [Math]::Max(50, $paperH - ($margin * 2))

                                            $imgW = $script:currentPrintImg.Width
                                            $imgH = $script:currentPrintImg.Height

                                            if ($imgW -gt 0 -and $imgH -gt 0) {
                                                $scale = [Math]::Min($availW / $imgW, $availH / $imgH)
                                                $dw = [int]($imgW * $scale)
                                                $dh = [int]($imgH * $scale)
                                                $dx = [int](($paperW - $dw) / 2)
                                                $dy = [int](($paperH - $dh) / 2)

                                                $destRect = New-Object System.Drawing.Rectangle($dx, $dy, $dw, $dh)

                                                $ev.Graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                                                $ev.Graphics.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality
                                                $ev.Graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality

                                                # CRITICAL FIX: Explicitly specify destination rectangle, source rectangle (0, 0, imgW, imgH) AND GraphicsUnit.Pixel
                                                # This completely eliminates WhatsApp JFIF 1-DPI scaling bug that caused images to render off-screen / blank!
                                                $ev.Graphics.DrawImage($script:currentPrintImg, $destRect, 0, 0, $imgW, $imgH, [System.Drawing.GraphicsUnit]::Pixel)
                                            }
                                        }
                                    } catch {
                                        LogMessage "[PRINT ERROR] Image render error: $_"
                                    }
                                    $ev.HasMorePages = $false
                                })

                                $pdoc.Print()
                                $ms.Dispose()
                                if ($script:currentPrintImg) {
                                    $script:currentPrintImg.Dispose()
                                    $script:currentPrintImg = $null
                                }
                                LogMessage "[SPOOL SUCCESS] Image printed cleanly to '$targetPrinter' (File $fileIdx/$totalF: $cleanName)."
                                Start-Sleep -Seconds 3
                            } catch {
                                try {
                                    $pinfo = New-Object System.Diagnostics.ProcessStartInfo
                                    $pinfo.FileName = $tmpFile
                                    if ($targetPrinter -and $targetPrinter -ne "Default Windows Printer") {
                                        $pinfo.Verb = "PrintTo"
                                        $pinfo.Arguments = "`"$targetPrinter`""
                                    } else {
                                        $pinfo.Verb = "Print"
                                    }
                                    $pinfo.CreateNoWindow = $true
                                    $pinfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
                                    $proc = [System.Diagnostics.Process]::Start($pinfo)
                                    if ($proc) { $proc.WaitForExit(10000) }
                                } catch {
                                    Start-Process -FilePath $tmpFile -Verb Print -PassThru | Out-Null
                                }
                                Start-Sleep -Seconds 3
                                LogMessage "[SPOOL SUCCESS] Sent image $fileIdx/$totalF to Windows printer."
                            }
                        } else {
                            # PDF document print with target printer routing and spool separation
                            try {
                                $pinfo = New-Object System.Diagnostics.ProcessStartInfo
                                $pinfo.FileName = $tmpFile
                                if ($targetPrinter -and $targetPrinter -ne "Default Windows Printer") {
                                    $pinfo.Verb = "PrintTo"
                                    $pinfo.Arguments = "`"$targetPrinter`""
                                } else {
                                    $pinfo.Verb = "Print"
                                }
                                $pinfo.CreateNoWindow = $true
                                $pinfo.WindowStyle = [System.Diagnostics.ProcessWindowStyle]::Hidden
                                $proc = [System.Diagnostics.Process]::Start($pinfo)
                                if ($proc) {
                                    $proc.WaitForExit(10000)
                                }
                            } catch {
                                Start-Process -FilePath $tmpFile -Verb Print -PassThru | Out-Null
                            }
                            # Crucial: 4-second spool settlement delay so Windows Spooler separates multi-page / multi-file jobs cleanly without blank paper!
                            Start-Sleep -Seconds 4
                            LogMessage "[SPOOL SUCCESS] Sent PDF $fileIdx/$totalF ($cleanName) to Windows printer."
                        }
                    }

                    # Report success
                    $report = @{ claimToken = $claimToken; status = "printed" } | ConvertTo-Json
                    Invoke-RestMethod -Uri "$Server/api/agent/jobs/$jobId/report" -Method Post -Headers $headers -Body $report -ContentType "application/json" -TimeoutSec 5 | Out-Null
                }
            }
        }
    } catch {
        # If server restarted or token expired, auto-re-pair using the permanent code so connection never breaks!
        $exMsg = $_.Exception.Message
        if ($exMsg -match "401" -or $exMsg -match "Unauthorized") {
            LogMessage "Token refreshed. Auto-re-authenticating with permanent code..."
            ConnectShopAgent($true)
        }
    }
})

[System.Windows.Forms.Application]::Run($Form)
